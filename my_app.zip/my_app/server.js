require('isomorphic-fetch');
// import fetch from 'isomorphic-fetch';

const express = require('express')
const app = express()
const port = 3000

app.get('/', (req, res) => res.send('Hello World!'))

app.listen(port, () => console.log(`Example app listening on port ${port}!`))


var test = fetch('https://revvio1-0.herokuapp.com/v1alpha1/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ "query": "{user { user_current_adult }}"}) //{"query":"{person{id}}"}
})
    .then(res => res.json())
    .then(res => console.log(res.data));

var test2 = fetch('https://revvio1-0.herokuapp.com/v1alpha1/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ "query": "{user { user_current_children }}"}) //{"query":"{person{id}}"}
})
    .then(res => res.json())
    .then(res => console.log(res.data));

// var root = {
//     abc: function ({user_first_name, user_last_name}) {
//         var output = [];
//         for (var i = 0; i < 2; i++) {
//             output.push(firstName[i]);
//         }
//         return output;
//     }
// };

console.log(test2);

// var obj = JSON.parse(test);
// console.log(obj.);
// var values = Object.values(test2);
// console.log(obj.user_current_children);
// console.log(test.user_current_adult);

// for(n1 in test){
//     for(n1_1 in test[n1]){
//         for(n1_2 in test[n1][n1_1]){
//             for(n1_3 in test[n1][n1_1][n1_2]){
//                 obj[test[n1][n1_1][n1_2].user_current_adult]=test[n1][n1_1][n1_2].value;
//                 console.log(obj);
//             }
//         }
//     }
// }
// console.log(obj);


// console.log(test+test2);